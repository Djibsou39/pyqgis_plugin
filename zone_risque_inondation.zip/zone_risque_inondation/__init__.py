# -*- coding: utf-8 -*-

def classFactory(iface):
    from .Zone_risque_inondation import ZoneRisque
    return ZoneRisque(iface)
